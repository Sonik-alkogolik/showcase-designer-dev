# [YooKassa API SDK](../home.md)

# Namespace: \YooKassa\Request\Payments\PaymentData\ElectronicCertificate

## Parent: [\YooKassa\Request\Payments\PaymentData](../namespaces/yookassa-request-payments-paymentdata.md)

### Classes

| Name | Summary |
| ---- | ------- |
| [\YooKassa\Request\Payments\PaymentData\ElectronicCertificate\ElectronicCertificateArticle](../classes/YooKassa-Request-Payments-PaymentData-ElectronicCertificate-ElectronicCertificateArticle.md) | Класс, представляющий модель ElectronicCertificateArticle. |

---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2026-03-13 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2026 YooMoney
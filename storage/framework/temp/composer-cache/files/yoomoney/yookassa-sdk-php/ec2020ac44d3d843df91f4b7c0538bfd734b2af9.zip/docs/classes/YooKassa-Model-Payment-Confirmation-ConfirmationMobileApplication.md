# [YooKassa API SDK](../home.md)

# Class: \YooKassa\Model\Payment\Confirmation\ConfirmationMobileApplication
### Namespace: [\YooKassa\Model\Payment\Confirmation](../namespaces/yookassa-model-payment-confirmation.md)
---
**Summary:**

Класс, представляющий модель ConfirmationMobileApplication.

**Description:**

Сценарий, при котором необходимо отправить плательщика на веб-страницу ЮKassa или партнера для
подтверждения платежа.

---
### Constants
* No constants found

---
### Properties
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [$confirmation_url](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md#property_confirmation_url) |  | URL на который необходимо перенаправить плательщика для подтверждения оплаты |
| public | [$confirmationUrl](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md#property_confirmationUrl) |  | URL на который необходимо перенаправить плательщика для подтверждения оплаты |
| public | [$type](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md#property_type) |  | Код сценария подтверждения |
| protected | [$_type](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md#property__type) |  | Код сценария подтверждения. |

---
### Methods
| Visibility | Name | Flag | Summary |
| ----------:| ---- | ---- | ------- |
| public | [__construct()](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md#method___construct) |  |  |
| public | [__get()](../classes/YooKassa-Common-AbstractObject.md#method___get) |  | Возвращает значение свойства. |
| public | [__isset()](../classes/YooKassa-Common-AbstractObject.md#method___isset) |  | Проверяет наличие свойства. |
| public | [__set()](../classes/YooKassa-Common-AbstractObject.md#method___set) |  | Устанавливает значение свойства. |
| public | [__unset()](../classes/YooKassa-Common-AbstractObject.md#method___unset) |  | Удаляет свойство. |
| public | [fromArray()](../classes/YooKassa-Common-AbstractObject.md#method_fromArray) |  | Устанавливает значения свойств текущего объекта из массива. |
| public | [getConfirmationData()](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md#method_getConfirmationData) |  |  |
| public | [getConfirmationToken()](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md#method_getConfirmationToken) |  |  |
| public | [getConfirmationUrl()](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md#method_getConfirmationUrl) |  |  |
| public | [getConfirmationUrl()](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md#method_getConfirmationUrl) |  | Возвращает URL на который необходимо перенаправить плательщика для подтверждения оплаты |
| public | [getType()](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md#method_getType) |  | Возвращает код сценария подтверждения. |
| public | [getValidator()](../classes/YooKassa-Common-AbstractObject.md#method_getValidator) |  |  |
| public | [jsonSerialize()](../classes/YooKassa-Common-AbstractObject.md#method_jsonSerialize) |  | Возвращает ассоциативный массив со свойствами текущего объекта для его дальнейшей JSON сериализации. |
| public | [offsetExists()](../classes/YooKassa-Common-AbstractObject.md#method_offsetExists) |  | Проверяет наличие свойства. |
| public | [offsetGet()](../classes/YooKassa-Common-AbstractObject.md#method_offsetGet) |  | Возвращает значение свойства. |
| public | [offsetSet()](../classes/YooKassa-Common-AbstractObject.md#method_offsetSet) |  | Устанавливает значение свойства. |
| public | [offsetUnset()](../classes/YooKassa-Common-AbstractObject.md#method_offsetUnset) |  | Удаляет свойство. |
| public | [setConfirmationUrl()](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md#method_setConfirmationUrl) |  | Устанавливает URL на который необходимо перенаправить плательщика для подтверждения оплаты |
| public | [setType()](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md#method_setType) |  | Устанавливает код сценария подтверждения |
| public | [toArray()](../classes/YooKassa-Common-AbstractObject.md#method_toArray) |  | Возвращает ассоциативный массив со свойствами текущего объекта для его дальнейшей JSON сериализации Является алиасом метода AbstractObject::jsonSerialize(). |
| protected | [getUnknownProperties()](../classes/YooKassa-Common-AbstractObject.md#method_getUnknownProperties) |  | Возвращает массив свойств которые не существуют, но были заданы у объекта. |
| protected | [validatePropertyValue()](../classes/YooKassa-Common-AbstractObject.md#method_validatePropertyValue) |  |  |

---
### Details
* File: [lib/Model/Payment/Confirmation/ConfirmationMobileApplication.php](../../lib/Model/Payment/Confirmation/ConfirmationMobileApplication.php)
* Package: YooKassa\Model
* Class Hierarchy:  
  * [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)
  * [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)
  * \YooKassa\Model\Payment\Confirmation\ConfirmationMobileApplication

* See Also:
  * [](https://yookassa.ru/developers/api)

---
### Tags
| Tag | Version | Description |
| --- | ------- | ----------- |
| category |  | Class |
| author |  | cms@yoomoney.ru |

---
## Properties
<a name="property_confirmation_url"></a>
#### public $confirmation_url : string
---
***Description***

URL на который необходимо перенаправить плательщика для подтверждения оплаты

**Type:** <a href="../string"><abbr title="string">string</abbr></a>

**Details:**


<a name="property_confirmationUrl"></a>
#### public $confirmationUrl : string
---
***Description***

URL на который необходимо перенаправить плательщика для подтверждения оплаты

**Type:** <a href="../string"><abbr title="string">string</abbr></a>

**Details:**


<a name="property_type"></a>
#### public $type : string
---
***Description***

Код сценария подтверждения

**Type:** <a href="../string"><abbr title="string">string</abbr></a>

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)


<a name="property__type"></a>
#### protected $_type : ?string
---
**Summary**

Код сценария подтверждения.

**Type:** <a href="../?string"><abbr title="?string">?string</abbr></a>

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)



---
## Methods
<a name="method___construct" class="anchor"></a>
#### public __construct() : mixed

```php
public __construct(mixed $data = []) : mixed
```

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\ConfirmationMobileApplication](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">mixed</code> | data  |  |

**Returns:** mixed - 


<a name="method___get" class="anchor"></a>
#### public __get() : mixed

```php
public __get(string $propertyName) : mixed
```

**Summary**

Возвращает значение свойства.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | propertyName  | Имя свойства |

**Returns:** mixed - Значение свойства


<a name="method___isset" class="anchor"></a>
#### public __isset() : bool

```php
public __isset(string $propertyName) : bool
```

**Summary**

Проверяет наличие свойства.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | propertyName  | Имя проверяемого свойства |

**Returns:** bool - True если свойство имеется, false если нет


<a name="method___set" class="anchor"></a>
#### public __set() : void

```php
public __set(string $propertyName, mixed $value) : void
```

**Summary**

Устанавливает значение свойства.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | propertyName  | Имя свойства |
| <code lang="php">mixed</code> | value  | Значение свойства |

**Returns:** void - 


<a name="method___unset" class="anchor"></a>
#### public __unset() : void

```php
public __unset(string $propertyName) : void
```

**Summary**

Удаляет свойство.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | propertyName  | Имя удаляемого свойства |

**Returns:** void - 


<a name="method_fromArray" class="anchor"></a>
#### public fromArray() : void

```php
public fromArray(array|\Traversable $sourceArray) : void
```

**Summary**

Устанавливает значения свойств текущего объекта из массива.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">array OR \Traversable</code> | sourceArray  | Ассоциативный массив с настройками |

**Returns:** void - 


<a name="method_getConfirmationData" class="anchor"></a>
#### public getConfirmationData() 

```php
public getConfirmationData() 
```

**Description**

Для ConfirmationQr

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)

**Returns:**  - 


<a name="method_getConfirmationToken" class="anchor"></a>
#### public getConfirmationToken() 

```php
public getConfirmationToken() 
```

**Description**

Для ConfirmationEmbedded

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)

**Returns:**  - 


<a name="method_getConfirmationUrl" class="anchor"></a>
#### public getConfirmationUrl() 

```php
public getConfirmationUrl() 
```

**Description**

Для ConfirmationRedirect

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)

**Returns:**  - 


<a name="method_getConfirmationUrl" class="anchor"></a>
#### public getConfirmationUrl() : string|null

```php
public getConfirmationUrl() : string|null
```

**Summary**

Возвращает URL на который необходимо перенаправить плательщика для подтверждения оплаты

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\ConfirmationMobileApplication](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md)

**Returns:** string|null - URL на который необходимо перенаправить плательщика для подтверждения оплаты


<a name="method_getType" class="anchor"></a>
#### public getType() : ?string

```php
public getType() : ?string
```

**Summary**

Возвращает код сценария подтверждения.

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)

**Returns:** ?string - 


<a name="method_getValidator" class="anchor"></a>
#### public getValidator() : \YooKassa\Validator\Validator

```php
public getValidator() : \YooKassa\Validator\Validator
```

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

**Returns:** \YooKassa\Validator\Validator - 


<a name="method_jsonSerialize" class="anchor"></a>
#### public jsonSerialize() : array

```php
public jsonSerialize() : array
```

**Summary**

Возвращает ассоциативный массив со свойствами текущего объекта для его дальнейшей JSON сериализации.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

**Returns:** array - Ассоциативный массив со свойствами текущего объекта


<a name="method_offsetExists" class="anchor"></a>
#### public offsetExists() : bool

```php
public offsetExists(string $offset) : bool
```

**Summary**

Проверяет наличие свойства.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | offset  | Имя проверяемого свойства |

**Returns:** bool - True если свойство имеется, false если нет


<a name="method_offsetGet" class="anchor"></a>
#### public offsetGet() : mixed

```php
public offsetGet(string $offset) : mixed
```

**Summary**

Возвращает значение свойства.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | offset  | Имя свойства |

**Returns:** mixed - Значение свойства


<a name="method_offsetSet" class="anchor"></a>
#### public offsetSet() : void

```php
public offsetSet(string $offset, mixed $value) : void
```

**Summary**

Устанавливает значение свойства.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | offset  | Имя свойства |
| <code lang="php">mixed</code> | value  | Значение свойства |

**Returns:** void - 


<a name="method_offsetUnset" class="anchor"></a>
#### public offsetUnset() : void

```php
public offsetUnset(string $offset) : void
```

**Summary**

Удаляет свойство.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | offset  | Имя удаляемого свойства |

**Returns:** void - 


<a name="method_setConfirmationUrl" class="anchor"></a>
#### public setConfirmationUrl() : self

```php
public setConfirmationUrl(string|null $confirmation_url = null) : self
```

**Summary**

Устанавливает URL на который необходимо перенаправить плательщика для подтверждения оплаты

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\ConfirmationMobileApplication](../classes/YooKassa-Model-Payment-Confirmation-ConfirmationMobileApplication.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string OR null</code> | confirmation_url  | URL на который необходимо перенаправить плательщика для подтверждения оплаты |

**Returns:** self - 


<a name="method_setType" class="anchor"></a>
#### public setType() : self

```php
public setType(string|null $type = null) : self
```

**Summary**

Устанавливает код сценария подтверждения

**Details:**
* Inherited From: [\YooKassa\Model\Payment\Confirmation\AbstractConfirmation](../classes/YooKassa-Model-Payment-Confirmation-AbstractConfirmation.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string OR null</code> | type  | Код сценария подтверждения |

**Returns:** self - 


<a name="method_toArray" class="anchor"></a>
#### public toArray() : array

```php
public toArray() : array
```

**Summary**

Возвращает ассоциативный массив со свойствами текущего объекта для его дальнейшей JSON сериализации
Является алиасом метода AbstractObject::jsonSerialize().

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

**Returns:** array - Ассоциативный массив со свойствами текущего объекта


<a name="method_getUnknownProperties" class="anchor"></a>
#### protected getUnknownProperties() : array

```php
protected getUnknownProperties() : array
```

**Summary**

Возвращает массив свойств которые не существуют, но были заданы у объекта.

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

**Returns:** array - Ассоциативный массив с не существующими у текущего объекта свойствами


<a name="method_validatePropertyValue" class="anchor"></a>
#### protected validatePropertyValue() : mixed

```php
protected validatePropertyValue(string $propertyName, mixed $propertyValue) : mixed
```

**Details:**
* Inherited From: [\YooKassa\Common\AbstractObject](../classes/YooKassa-Common-AbstractObject.md)

##### Parameters:
| Type | Name | Description |
| ---- | ---- | ----------- |
| <code lang="php">string</code> | propertyName  |  |
| <code lang="php">mixed</code> | propertyValue  |  |

**Returns:** mixed - 



---

### Top Namespaces

* [\YooKassa](../namespaces/yookassa.md)

---

### Reports
* [Errors - 0](../reports/errors.md)
* [Markers - 0](../reports/markers.md)
* [Deprecated - 43](../reports/deprecated.md)

---

This document was automatically generated from source code comments on 2026-03-13 using [phpDocumentor](http://www.phpdoc.org/)

&copy; 2026 YooMoney